<?php

namespace FacturaScripts\Plugins\DiarioProyectos\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;

class DiarioProyecto extends ModelClass
{
    use ModelTrait;

    /** @var int */
    public $id;

    /** @var string */
    public $uid;

    /** @var int */
    public $idproyecto;

    /** @var string */
    public $fecha;

    /** @var string */
    public $titulo;

    /** @var string */
    public $descripcion;

    public static function primaryColumn(): string
    {
        return 'id';
    }

    public static function tableName(): string
    {
        return 'diarioproyectos';
    }
}

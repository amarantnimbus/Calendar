<?php

namespace FacturaScripts\Plugins\DiarioProyectos\Controller;

use FacturaScripts\Core\Lib\ExtendedController\ListController;

class ListDiarioProyecto extends ListController
{
    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'sales';
        $data['title'] = 'project-diary';
        $data['icon'] = 'fa-solid fa-book';
        return $data;
    }

    protected function createViews()
    {
        $this->addView('ListDiarioProyecto', 'DiarioProyecto', 'project-diary', 'fa-solid fa-book');
        $this->addSearchFields('ListDiarioProyecto', ['titulo', 'descripcion']);
        $this->addOrderBy('ListDiarioProyecto', ['fecha', 'id'], 'date', 2);

        $projects = $this->codeModel->all('proyectos', 'idproyecto', 'nombre');
        $this->addFilterSelect('ListDiarioProyecto', 'idproyecto', 'project', 'idproyecto', $projects);
    }
}
